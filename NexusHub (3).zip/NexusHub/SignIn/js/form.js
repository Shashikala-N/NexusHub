function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}

function validateForm() {
    var name = document.Form.name.value;
    var email = document.Form.email.value;
    var pass = document.Form.pass.value;

    var nameError = emailError = passError = true;

    // Name validation
    if (name == "") {
        printError("nameError", "Please enter your name");
        var elem = document.getElementById("name");
        elem.classList.add("input-2");
        elem.classList.remove("input-1");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(name) === false) {
            printError("nameError", "Please enter a valid name");
            var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("nameError", "");
            nameError = false;
            var elem = document.getElementById("name");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");
        }
    }

    // Email validation
    if (email == "") {
        printError("emailError", "Please enter your email address");
        var elem = document.getElementById("email");
        elem.classList.add("input-2");
        elem.classList.remove("input-1");
    } else {
        var regex = /^\S+@\S+\.\S+$/;
        if (regex.test(email) === false) {
            printError("emailError", "Please enter a valid email address");
            var elem = document.getElementById("email");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("emailError", "");
            emailError = false;
            var elem = document.getElementById("email");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");
        }
    }

    // Password validation
    if (pass == "") {
        printError("passError", "Please enter the password");
        var elem = document.getElementById("pass");
        elem.classList.add("input-2");
        elem.classList.remove("input-1");
    } else {
        // Example password regex: at least 6 characters, including one number and one special character
        var regex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/;
        if (regex.test(pass) === false) {
            printError("passError", "Please enter a valid password");
            var elem = document.getElementById("pass");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("passError", "");
            passError = false;
            var elem = document.getElementById("pass");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");
        }
    }

    if ((nameError || emailError || passError) == true) {
        return false;
    }
}
